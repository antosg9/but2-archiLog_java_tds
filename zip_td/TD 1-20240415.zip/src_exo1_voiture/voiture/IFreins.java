package voiture;

public interface IFreins {

  void freiner(Voiture voiture);

  void r�parer();

}
