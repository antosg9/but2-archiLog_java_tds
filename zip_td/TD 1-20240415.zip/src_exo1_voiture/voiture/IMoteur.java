package voiture;

public interface IMoteur {

  int getVitesseMaximale(Voiture voiture);

  void acc�l�rer(Voiture voiture);

}
